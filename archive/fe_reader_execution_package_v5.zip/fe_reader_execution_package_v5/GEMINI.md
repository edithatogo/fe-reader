# Gemini / Conductor Entry Instructions

This repository contains a Conductor-ready specification package.

Read in this order:

1. `conductor/product.md`
2. `conductor/tech-stack.md`
3. `conductor/waves.yaml`
4. `conductor/tracks.md`
5. `conductor/review-policy.md`
6. `docs/architecture.md`
7. `contracts/README.md`

Then implement Wave 0. Keep all code compileable after each phase.
