# Fe Reader Execution-Ready Specification Package v4

Fe Reader is a local-first, cross-platform PDF workflow platform built around a headless Rust core. This package is designed to be extracted into a repository and handed to a coding model/agent runner as its implementation source of truth.

The product is **not** a legal-only application. Legal/affidavit automation is one workflow pack among many. The platform supports reading, editing, metadata control, conversion, workflow automation, deterministic search, accessibility, platform integration, app integration, performance engineering, release engineering, security isolation, compatibility testing, and late-stage optional local intelligence.

## How to use this package

1. Extract this folder into a new repository.
2. Read `IMPLEMENTATION_PROMPT.md`, `AGENTS.md`, `conductor/waves.yaml`, and `contracts/README.md` first.
3. Copy sample crate manifests from `crates/**/Cargo.toml.sample` into their final names when creating the workspace.
4. Install Conductor and ask the coding model to begin with Wave 0.
5. Use `scripts/conductor_phase_gate.sh --phase <phase-id> --auto-fix` after every phase.

## Core principle

Every potentially destructive operation must flow through:

```text
OperationIntent -> PatchPlan -> Review/Policy -> Apply -> Verify -> AuditReceipt
```

This applies equally to UI actions, CLI commands, MCP calls, plugins, COM/AppleScript/D-Bus automation, browser extension calls, and mobile intents.

## v4 additions

v4 incorporates the performance/bleeding-edge layer from v3 and adds the final operating-excellence layer:

```text
Security isolation and process sandboxing
Compatibility corpus governance and visual regression testing
Deterministic search/indexing without early ML dependency
Text, font, Unicode, CJK, RTL and accessibility contracts
Release operations, signed updates, SBOMs and provenance
Enterprise deployment policy and privacy/diagnostics governance
Developer ecosystem, SDK and API versioning
```

## Package map

```text
docs/                  Product, architecture, platform, metadata, conversion, distribution, security, performance and QA plans
contracts/             Rust traits, automation surfaces, platform contracts, MCP, CLI, web, policy and search contracts
schemas/               JSON Schemas for operations, patch plans, workflows, metadata, plugins, packaging, policy and test fixtures
conductor/             Conductor context files, waves, tracks, review policy and automation manifest
.agents/skills/        Review skill for phase gates
crates/                Cargo.toml samples for the intended Rust workspace
scripts/               Phase gate, architecture compliance, schema validation, release, security, corpus and performance checks
templates/             Workflow packs, signature templates, redaction recipes, metadata profiles and enterprise policies
packaging/             Distribution manifests/checklists for Windows, macOS, Linux, Android, iOS, NuGet and update channels
third_party/           Fork/submodule policy and library contribution strategy
benchmarks/            Performance budgets, scenarios, reports and benchmark harness plan
ci/                    Sample CI jobs including performance, compatibility, security and release readiness runs
```

## What is intentionally deferred

Local LLMs, RAG and ML-heavy NLP are not early priorities. The architecture includes late-wave contracts for local intelligence, but Waves 0-5 focus on deterministic parsing, rendering, editing, metadata, secure redaction, workflow packs, OS integration, installers, external integrations, deterministic search and release quality. Wave 6 remains optional frontier work.

# v5 additions

Version 5 adds the final execution-readiness layer for a coding model: requirements traceability, ADR governance, public API compatibility, reproducible developer environments, local automation API contracts, transaction journaling/undo, differential/property/mutation testing, managed enterprise policy templates, and an explicit plugin/template developer ecosystem.

Start here for implementation:

1. `IMPLEMENTATION_PROMPT.md`
2. `AGENTS.md`
3. `conductor/waves.yaml`
4. `conductor/tracks.md`
5. `docs/final-v5-improvements.md`
6. `docs/requirements-traceability.md`
7. `docs/testing-property-mutation-differential.md`
8. `docs/workspace-undo-transaction-journal.md`
9. `docs/reproducible-builds-dev-environments.md`

The v5 principle is: **stable deterministic core, measurable performance, frontier lanes at the edges, and every risky operation represented as a typed intent, plan, transaction, verification result, and receipt.**
