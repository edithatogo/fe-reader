#!/usr/bin/env python3
from pathlib import Path
import argparse, sys
parser = argparse.ArgumentParser()
parser.add_argument('--workspace-root', default='.')
args = parser.parse_args()
adr_dir = Path(args.workspace_root) / 'docs' / 'adr'
if not adr_dir.exists():
    print('missing docs/adr', file=sys.stderr)
    sys.exit(2)
missing = []
for p in adr_dir.glob('*.md'):
    txt = p.read_text(encoding='utf-8')
    for word in ['Status:', '## Context', '## Decision', '## Consequences', '## Rollback criteria']:
        if word not in txt:
            missing.append((p.name, word))
if missing:
    for item in missing:
        print('ADR missing section:', item, file=sys.stderr)
    sys.exit(3)
print(f'adr ok: {len(list(adr_dir.glob("*.md")))} ADRs')
