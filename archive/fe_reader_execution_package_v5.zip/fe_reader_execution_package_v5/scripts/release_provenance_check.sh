#!/usr/bin/env bash
set -euo pipefail
printf 'Checking release provenance prerequisites...\n'
test -f ci/release-provenance.yml.sample
test -f packaging/release-channels.yaml
test -f schemas/update-manifest.schema.json
printf 'release provenance scaffolding ok\n'
