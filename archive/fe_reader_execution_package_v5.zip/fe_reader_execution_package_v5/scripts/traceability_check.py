#!/usr/bin/env python3
from pathlib import Path
import argparse, re, sys
parser = argparse.ArgumentParser()
parser.add_argument('--workspace-root', default='.')
args = parser.parse_args()
root = Path(args.workspace_root)
req = root / 'docs' / 'requirements-traceability.md'
if not req.exists():
    print('missing docs/requirements-traceability.md', file=sys.stderr)
    sys.exit(2)
text = req.read_text(encoding='utf-8')
ids = set(re.findall(r'FR-[A-Z]+-\d{3}', text))
if len(ids) < 20:
    print(f'expected at least 20 requirement IDs, found {len(ids)}', file=sys.stderr)
    sys.exit(3)
print(f'traceability ok: {len(ids)} requirement IDs')
