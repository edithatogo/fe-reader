# Fe Reader Review Skill

Run this skill at the end of every Conductor phase.

## Commands

```bash
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace --all-features
python3 scripts/validate_schemas.py
python3 scripts/architecture_compliance_check.py --workspace-root .
python3 scripts/corpus_manifest_validate.py
scripts/security_policy_check.sh || true
scripts/sbom_audit.sh || true
scripts/perf_smoke.sh || true
python3 scripts/visual_regression_compare.py --smoke || true
scripts/release_readiness_check.sh || true
```

Then run advisory checks if available:

```bash
cargo deny check
cargo audit
cargo vet
cargo cyclonedx --format json --output-file target/sbom.cdx.json
```

## Architecture checks

Fail if:

- `fe_reader_core` depends on Tauri, PDFium, MCP, Extism, Wasmtime, Candle, Burn, platform crates, webview crates, OS automation crates, database/index crates, or UI frameworks.
- Secure redaction uses incremental append.
- Automation APIs mutate without approval tokens.
- Plugin host can directly write documents.
- Web integration can mutate files without explicit user grant.
- Platform adapters leak OS-specific types into core contracts.
- Renderer or search/indexing code mutates source documents.
- P0/P1 performance budgets regress after baselines are accepted.
- GPU, PGO, allocator, git dependencies or local-intelligence experiments become default without benchmark evidence.
- JavaScript actions, RichMedia, external file launch, embedded executables, network fetches, or plugin code execute without sandbox policy and user consent.
- Signed-update manifests are unsigned or are not bound to artifact digests.

## Auto-fix

Allowed for formatting, schema formatting and simple machine-applicable lints only. Do not auto-fix security, redaction, architecture, platform permission, corpus, release-signing, policy, or accepted performance-regression failures.

## v5 review additions

At the end of every phase, additionally check:

```bash
python3 scripts/traceability_check.py --workspace-root .
python3 scripts/adr_check.py --workspace-root .
cargo nextest run --workspace --all-features --profile ci
cargo public-api --workspace || true
cargo semver-checks || true
```

Do not auto-fix failures in traceability, ADR, public API, semver, security policy, redaction verification, transaction journal, enterprise policy, plugin capability or release provenance checks.
