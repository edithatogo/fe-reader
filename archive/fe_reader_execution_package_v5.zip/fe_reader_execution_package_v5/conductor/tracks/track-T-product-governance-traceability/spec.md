# Track T-PRODUCT-GOVERNANCE-TRACEABILITY: Product Governance, Traceability and ADRs

## Objective

Maintain requirements matrix, ADR backlog, acceptance criteria, release playbooks and scope control.

## Required references

- `docs/requirements-traceability.md`
- `docs/architecture-decision-records.md`
- `docs/final-v5-improvements.md`
- `conductor/waves.yaml`

## Completion rule

Every phase must end with the review skill, quality matrix, architecture compliance check and traceability update.
