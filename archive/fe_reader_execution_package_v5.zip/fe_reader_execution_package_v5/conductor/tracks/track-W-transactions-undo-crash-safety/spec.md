# Track W-TRANSACTIONS-UNDO-CRASH-SAFETY: Transactions, Undo and Crash Safety

## Objective

Implement operation transaction journal, undo/redo, crash recovery, atomic writes and receipt linkage.

## Required references

- `docs/requirements-traceability.md`
- `docs/architecture-decision-records.md`
- `docs/final-v5-improvements.md`
- `conductor/waves.yaml`

## Completion rule

Every phase must end with the review skill, quality matrix, architecture compliance check and traceability update.
