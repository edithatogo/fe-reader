# Track V-REPRODUCIBLE-BUILDS-PROVENANCE: Reproducible Builds and Provenance

## Objective

Add devcontainer/Nix/xtask, SBOM, artifact attestations, SLSA verification, public API compatibility and release build reproducibility.

## Required references

- `docs/requirements-traceability.md`
- `docs/architecture-decision-records.md`
- `docs/final-v5-improvements.md`
- `conductor/waves.yaml`

## Completion rule

Every phase must end with the review skill, quality matrix, architecture compliance check and traceability update.
