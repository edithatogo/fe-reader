# Track Y-TEMPLATE-DEVTOOLS-MARKETPLACE: Workflow Template DevTools and Marketplace

## Objective

Implement workflow lint/test/package commands, template language support, plugin marketplace manifest policy.

## Required references

- `docs/requirements-traceability.md`
- `docs/architecture-decision-records.md`
- `docs/final-v5-improvements.md`
- `conductor/waves.yaml`

## Completion rule

Every phase must end with the review skill, quality matrix, architecture compliance check and traceability update.
