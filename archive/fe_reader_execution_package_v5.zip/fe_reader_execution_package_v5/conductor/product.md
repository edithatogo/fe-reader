# Product Context: Fe Reader

Fe Reader is a local-first PDF workflow platform with a headless Rust core. It supports reading, editing, metadata control, verified redaction, workflow packs, conversion, native OS integration, app integrations, safe automation, and late-stage local intelligence.

Fe Reader is not legal-only. Legal workflows are one pack among many.

The product should be described as offering **industry baseline parity** plus local-first workflow automation, metadata transparency, and verified operations.
