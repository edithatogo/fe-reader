# Transactions and Automation Style Guide

- No destructive operation may be implemented as a direct function call from UI or automation.
- Always build a typed intent first.
- Always build a patch plan next.
- Always write a transaction journal before output mutation.
- Always verify output before commit.
- Always emit a receipt for high-risk operations.
- Automation surfaces are read-only by default.
- Local API endpoints must be loopback-only unless an enterprise policy explicitly enables otherwise.
