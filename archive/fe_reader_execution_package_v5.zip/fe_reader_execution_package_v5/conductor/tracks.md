# Tracks

| Track | Theme | Main wave(s) | Summary |
|---|---|---:|---|
| A Core Engine | Foundation | 0-3 | Core contracts, patch planning, PDF operations |
| B Rendering & Hardware | Reader | 1-6 | PDFium rendering, tiles, GPU compositor option |
| C Bindings & ABI | Native | 1-5 | UniFFI, C# wrapper, stable ABI |
| D UI & Native Shell | Reader | 1-4 | Tauri/Svelte shell, mobile wrappers, document UX |
| E Platform Integration | Native | 1-5 | Windows/macOS/Linux/Android/iOS OS integration |
| F Workflow Packs | Workflows | 2-4 | Domain workflow packs and template engine |
| G Metadata, Standards & Preflight | Pro docs | 2-5 | XMP, scrub, PDF 2.0, PDF/A/UA/X adapters |
| H Conversion & Source Pipelines | Publishing | 4-5 | Markdown/DOCX/HTML/Typst/Quarto/LaTeX/Pandoc |
| I External Integrations | Integrations | 5 | Zotero, Obsidian, browser extension, storage providers |
| J Distribution & Publishing | Release | 4-7 | installers, registries, stores, local/global install, signed updates |
| K Security & Quality | Foundation | 0-7 | fuzzing, supply chain, redaction verification, review skill |
| L Web & Browser | Integrations | 5 | Web local/PWA and browser extension |
| M Frontier Intelligence | Frontier | 6 | optional local NLP, embeddings, grounded Q&A |
| N Performance Engineering | Performance | 0-7 | budgets, benchmarks, profiling, PGO/LTO, perf gates |
| O Security Isolation & Policy | Safety | 0-7 | threat model, sandboxing, permissions, automation policy |
| P Compatibility Corpus & Visual QA | Quality | 0-7 | fixtures, visual regression, differential tests, corpus governance |
| Q Search, Text, Fonts & I18N | Reader | 1-7 | deterministic index, Unicode, CJK/RTL, font fallback, accessibility text |
| R Release Ops & Enterprise | Operations | 4-7 | signed updates, SBOM/provenance, policy templates, supportability |
| S Developer Ecosystem & SDK | Ecosystem | 5-7 | public SDK contracts, API versioning, plugin devkit, docs |

## Parallelisation rules

- A0, K0, O0 and P0 run first.
- B, C, D, E, N and Q may proceed in parallel after A0 core types compile.
- P visual-regression harness may begin as soon as B can render a fixture.
- R begins in Wave 4, but release-policy documents may be drafted earlier.
- S begins in Wave 5 after the CLI, MCP and plugin surfaces have stable contracts.
- M is optional and cannot block release hardening.

## v5 additional tracks

| Track | Theme | Purpose |
|---|---|---|
| T | Governance | Requirements traceability, ADRs, release acceptance and scope control |
| U | Testing | Property, mutation, metamorphic, differential, visual and standards tests |
| V | Build/Release | Reproducible environments, SBOM, artifact attestations and public API compatibility |
| W | Safety | Transaction journal, undo/redo and crash recovery |
| X | Automation/Enterprise | Local OpenAPI/JSON-RPC, managed policy templates and safe automation controls |
| Y | Ecosystem | Workflow template language, devtools and marketplace governance |
| Z | Expert PDF | Document health, lint/fix, PDF diff and object inspector |
