# Implementation Prompt for Coding Agent

You are implementing Fe Reader, a local-first cross-platform PDF workflow platform. You must treat this repository as an execution-ready specification package, not as a loose set of ideas.

## First files to read

Read these in order:

1. `README.md`
2. `AGENTS.md`
3. `conductor/waves.yaml`
4. `conductor/tracks.md`
5. `contracts/README.md`
6. `docs/architecture.md`
7. `docs/security-threat-model.md`
8. `docs/performance-engineering.md`
9. `docs/compatibility-corpus-governance.md`
10. `docs/release-operations-updates.md`

## Implementation rules

- Do not put UI, Tauri, PDFium, MCP, platform APIs, Extism, Wasmtime, Candle, Burn, COM, AppleScript, D-Bus, or web APIs into `fe_reader_core`.
- Implement deterministic functionality before ML. ML, local LLMs, embeddings and RAG are Wave 6+ only.
- Implement a CLI path as early as possible so every operation can be tested outside the UI.
- Treat all external automation surfaces as untrusted. Read-only by default; mutations require `PatchPlan` and explicit approval.
- Secure redaction must use full sanitising rewrite and verification. Do not implement secure redaction as an annotation-only black box.
- Renderer crashes must not corrupt documents. Rendering and mutation are separate concerns.
- The project is local-first. Do not add cloud sync. External storage integrations must be explicit providers or OS-level document providers.
- Use upstream libraries first; fork only according to `third_party/fork-policy.yaml`.
- Performance budgets are product requirements, not optional polish.

## Starting command

Begin with:

```text
/conductor:status
/conductor:implement Wave 0 Foundation Contracts, CLI Harness, Security Policy and Corpus Baseline
```

## Phase exit rule

At the end of every phase, run:

```bash
scripts/conductor_phase_gate.sh --phase <phase-id> --auto-fix
```

Formatting and simple lint fixes may be automatic. Security, architecture, redaction, policy, release-signing, compatibility and accepted performance failures must not be auto-bypassed.

## v5 implementation directive

In addition to the previous package instructions, the implementation agent must now treat the following as mandatory before feature coding expands beyond the first reader milestone:

- Maintain `docs/requirements-traceability.md` and link every implemented task to a requirement ID.
- Add an ADR for any change that affects crate boundaries, PDF write semantics, automation surfaces, public API compatibility, storage/journaling, plugin capabilities, or release/security policy.
- Use the operation transaction model in `contracts/rust/operation_transaction.rs` for all mutating operations.
- Implement cancellation/resource-limit propagation early; no parser/render/workflow API may be unbounded.
- Use `cargo nextest` for the main test runner, with property and differential tests staged into CI after the CLI smoke harness exists.
- Keep local ML/RAG features out of early waves. Wave 6 may evaluate them only after deterministic text extraction, search, redaction, and verification are stable.
- Treat `contracts/openapi/fe-reader-local-api.openapi.yaml` as the local automation contract. The API is loopback-only, policy-gated, and read-only by default.
