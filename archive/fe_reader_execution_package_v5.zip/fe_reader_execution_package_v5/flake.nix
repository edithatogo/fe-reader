{
  description = "Fe Reader development shell";
  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
    flake-utils.url = "github:numtide/flake-utils";
  };
  outputs = { self, nixpkgs, flake-utils }:
    flake-utils.lib.eachDefaultSystem (system:
      let pkgs = import nixpkgs { inherit system; };
      in {
        devShells.default = pkgs.mkShell {
          packages = with pkgs; [
            rustup pkg-config openssl nodejs_22 pnpm jdk21 python312 jq shellcheck git
          ];
          RUST_BACKTRACE = "1";
        };
      });
}
