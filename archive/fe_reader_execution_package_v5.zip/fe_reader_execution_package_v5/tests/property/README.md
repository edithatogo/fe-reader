# Property Tests

Initial invariants:

- Coordinate transforms round-trip across crop/rotation/scale.
- Page operations preserve page count expectations and document hash changes.
- Metadata scrub preserves allow-listed fields and removes deny-listed fields.
- Workflow compilation is deterministic.
- Transaction journal state transitions are valid.
