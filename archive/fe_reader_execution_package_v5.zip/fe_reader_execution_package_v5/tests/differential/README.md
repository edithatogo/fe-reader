# Differential Tests

Compare Fe Reader outputs against independent tools where available.

Targets:

- PDFium vs PDF.js render for golden fixtures.
- Fe extraction vs external extraction for stable text fixtures.
- Fe metadata view vs qpdf/exiftool-style external metadata where available.
- Fe redaction verification vs external text extraction where available.

Differential tests are advisory until fixture baselines are stable.
