# Mutation Tests

Use mutation testing on high-value pure logic:

- patch planner;
- redaction planner;
- metadata scrubber;
- security policy;
- transaction state machine;
- coordinate transforms.

Run nightly or manually, not on every quick PR.
