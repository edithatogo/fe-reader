//! Operation transaction contract.
//! Every mutating operation must pass through this lifecycle.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperationTransaction {
    pub transaction_id: String,
    pub intent_id: String,
    pub input_document_sha256: String,
    pub patch_plan_sha256: String,
    pub state: TransactionState,
    pub created_at_utc: String,
    pub updated_at_utc: String,
    pub write_mode: WriteMode,
    pub recovery: RecoveryPolicy,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum TransactionState {
    Planned,
    Prepared,
    Writing,
    Verifying,
    Committed,
    RolledBack,
    FailedNeedsRecovery,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum WriteMode {
    IncrementalAppend,
    FullSanitizingRewrite,
    NewOutputFile,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecoveryPolicy {
    pub allow_commit_if_verified: bool,
    pub allow_rollback: bool,
    pub preserve_temp_outputs: bool,
}

pub trait TransactionJournal {
    fn begin(&self, tx: OperationTransaction) -> anyhow::Result<()>;
    fn transition(&self, transaction_id: &str, state: TransactionState) -> anyhow::Result<()>;
    fn commit(&self, transaction_id: &str) -> anyhow::Result<()>;
    fn rollback(&self, transaction_id: &str) -> anyhow::Result<()>;
    fn recoverable(&self) -> anyhow::Result<Vec<OperationTransaction>>;
}
