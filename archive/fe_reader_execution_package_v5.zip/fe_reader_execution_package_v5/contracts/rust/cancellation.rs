//! Cancellation contract for long operations.

use serde::{Deserialize, Serialize};
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};

#[derive(Clone, Default)]
pub struct CancellationToken {
    cancelled: Arc<AtomicBool>,
}

impl CancellationToken {
    pub fn cancel(&self) { self.cancelled.store(true, Ordering::SeqCst); }
    pub fn is_cancelled(&self) -> bool { self.cancelled.load(Ordering::SeqCst) }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProgressEvent {
    pub operation_id: String,
    pub stage: String,
    pub completed_units: u64,
    pub total_units: Option<u64>,
    pub message: Option<String>,
}

pub trait ProgressSink: Send + Sync {
    fn emit(&self, event: ProgressEvent);
}
