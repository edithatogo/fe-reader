//! Interoperability validation contract.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InteropValidationRequest {
    pub document_path: String,
    pub profiles: Vec<InteropProfile>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum InteropProfile {
    BasicSyntax,
    SafeShare,
    SecureRedaction,
    ArchivePdfA,
    AccessibilityPdfUa,
    PrintProductionPdfX,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InteropValidationResult {
    pub profile: InteropProfile,
    pub passed: bool,
    pub findings: Vec<String>,
    pub external_tool: Option<String>,
}
