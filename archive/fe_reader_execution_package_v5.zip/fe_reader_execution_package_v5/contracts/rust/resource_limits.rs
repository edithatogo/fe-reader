//! Resource-limit contract.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResourceLimits {
    pub max_wall_time_ms: Option<u64>,
    pub max_memory_mb: Option<u64>,
    pub max_pages: Option<u32>,
    pub max_render_pixels: Option<u64>,
    pub max_embedded_file_bytes: Option<u64>,
    pub max_object_depth: Option<u32>,
    pub max_incremental_revisions: Option<u32>,
    pub max_plugin_time_ms: Option<u64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ResourceLimitError {
    TimeExceeded { limit_ms: u64 },
    MemoryExceeded { limit_mb: u64 },
    PageLimitExceeded { limit: u32 },
    RenderPixelLimitExceeded { limit: u64 },
    ObjectDepthExceeded { limit: u32 },
    PluginBudgetExceeded { limit_ms: u64 },
}
