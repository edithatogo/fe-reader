//! Local automation API contract.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AutomationSession {
    pub session_id: String,
    pub client_name: String,
    pub read_only: bool,
    pub expires_at_utc: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApprovalToken {
    pub token_id: String,
    pub plan_sha256: String,
    pub expires_at_utc: String,
    pub approved_by: String,
}

pub trait LocalAutomationApi {
    fn open_document_readonly(&self, path: String) -> anyhow::Result<String>;
    fn inspect_document(&self, document_id: String) -> anyhow::Result<serde_json::Value>;
    fn build_patch_plan(&self, document_id: String, operation: serde_json::Value) -> anyhow::Result<serde_json::Value>;
    fn apply_approved_plan(&self, plan_id: String, approval: ApprovalToken) -> anyhow::Result<serde_json::Value>;
}
