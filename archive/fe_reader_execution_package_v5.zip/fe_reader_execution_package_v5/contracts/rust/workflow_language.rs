//! Workflow language contract.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkflowPack {
    pub workflow_id: String,
    pub version: String,
    pub display_name: String,
    pub risk_level: RiskLevel,
    pub requires_human_review: bool,
    pub steps: Vec<WorkflowStep>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum RiskLevel { Low, Medium, High, Critical }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkflowStep {
    pub step_id: String,
    pub step_type: String,
    pub parameters_json: serde_json::Value,
    pub produces: Vec<String>,
    pub requires: Vec<String>,
}

pub trait WorkflowCompiler {
    fn lint(&self, pack: &WorkflowPack) -> anyhow::Result<Vec<WorkflowLint>>;
    fn compile_to_plan(&self, pack: &WorkflowPack, document_id: &str) -> anyhow::Result<String>;
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkflowLint {
    pub severity: String,
    pub code: String,
    pub message: String,
    pub path: String,
}
