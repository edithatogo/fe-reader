//! Plugin/workflow marketplace contract.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MarketplacePackageRecord {
    pub package_id: String,
    pub package_type: PackageType,
    pub version: String,
    pub publisher: PublisherIdentity,
    pub license: String,
    pub source_repository: Option<String>,
    pub sha256: String,
    pub signature: Option<String>,
    pub required_capabilities: Vec<String>,
    pub compatibility: CompatibilityRange,
    pub trust_level: TrustLevel,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum PackageType { WorkflowPack, TemplatePack, RedactionRecipe, ConverterProvider, WasmPlugin }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PublisherIdentity { pub name: String, pub url: Option<String>, pub verified: bool }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompatibilityRange { pub min_fe_version: String, pub max_fe_version: Option<String> }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum TrustLevel { LocalDev, Community, VerifiedPublisher, Official, EnterpriseApproved }
