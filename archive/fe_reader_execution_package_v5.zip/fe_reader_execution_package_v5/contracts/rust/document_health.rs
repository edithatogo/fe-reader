//! Document health report contract.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DocumentHealthReport {
    pub document_sha256: String,
    pub overall_score: u8,
    pub findings: Vec<DocumentHealthFinding>,
    pub generated_at_utc: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DocumentHealthFinding {
    pub finding_id: String,
    pub category: HealthCategory,
    pub severity: Severity,
    pub page_index: Option<u32>,
    pub object_id: Option<String>,
    pub message: String,
    pub suggested_fix: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum HealthCategory { Syntax, Security, Privacy, Accessibility, Print, Workflow, Performance }
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum Severity { Info, Low, Medium, High, Critical }
