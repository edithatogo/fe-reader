//! Undo/redo journal contract.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UndoEntry {
    pub undo_id: String,
    pub transaction_id: String,
    pub document_before_sha256: String,
    pub document_after_sha256: String,
    pub semantic_inverse_available: bool,
    pub inverse_patch_plan_sha256: Option<String>,
    pub snapshot_path: Option<String>,
}

pub trait UndoJournal {
    fn record(&self, entry: UndoEntry) -> anyhow::Result<()>;
    fn can_undo(&self, document_id: &str) -> anyhow::Result<bool>;
    fn build_undo_plan(&self, undo_id: &str) -> anyhow::Result<String>;
    fn build_redo_plan(&self, undo_id: &str) -> anyhow::Result<String>;
}
