# Agent Instructions

## Product identity

Fe Reader is a local-first PDF workflow platform with strong privacy, verification, metadata transparency, automation safety and cross-platform native integration. It should meet industry baseline PDF capabilities without framing the product as a clone of any vendor.

## Non-negotiable architecture

```text
fe_reader_core
  pure document/workflow core
  no UI, no platform, no renderer, no AI, no MCP, no plugin runtime

adapters
  rendering, platform, app integrations, MCP, plugins, web, native shell
```

## Mutation pipeline

All writes use:

```text
OperationIntent -> PatchPlan -> Review/Policy -> Apply -> Verify -> AuditReceipt
```

No shortcut APIs.

## Automation safety

COM, AppleScript, D-Bus, MCP, mobile intents, browser extensions and plugins are read-only by default. Mutations require:

- document hash match
- patch plan ID
- policy evaluation
- approval token or interactive confirmation
- audit receipt emission

## Testing expectations

Every core feature needs at least one of:

- CLI golden test
- schema validation
- fuzz target
- visual regression fixture
- differential test against reference renderer/tool
- platform contract smoke test
- performance scenario budget

## Dependency rule

Use latest verified stable dependencies. Bleeding-edge or git dependencies are allowed only in frontier lanes with an owner, feature gate, rollback plan and exit criteria.

## v5 agent constraints

Agents must not implement direct destructive actions from UI, CLI, MCP, COM, AppleScript, D-Bus, Android intents, iOS App Intents, browser extension calls, or the local HTTP API. Every mutation must follow:

`OperationIntent -> PatchPlan -> TransactionJournal -> Apply -> Verify -> Receipt`.

Agents must update requirement traceability and ADRs as part of implementation. A change is incomplete until it has tests, acceptance criteria, and an explicit rollback/migration note when it touches persisted state or public API.
