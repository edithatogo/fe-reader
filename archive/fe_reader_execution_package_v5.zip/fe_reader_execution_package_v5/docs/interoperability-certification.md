# Interoperability and Certification Plan

## Why it matters

Fe Reader must produce PDFs that other tools can open, inspect, print and archive. It should validate output against independent tools rather than trusting itself.

## Independent validation adapters

- veraPDF for PDF/A and PDF/UA where available.
- qpdf for syntax/object sanity checks.
- PDFium/PDF.js for rendering sanity.
- external text extraction tools for differential checks.
- Ghostscript or print-oriented tools where available for print workflows.

## Profiles

| Profile | Purpose |
|---|---|
| `basic-pdf-syntax` | Opens and parses without structural errors |
| `safe-share` | metadata and risky actions scrubbed |
| `secure-redaction` | no residual selected content found |
| `archive` | PDF/A candidate validation |
| `accessibility` | PDF/UA candidate validation |
| `print-production` | PDF/X/preflight-style checks |

## Certification target

Do not claim formal conformance until an external validator and test corpus support the claim.
