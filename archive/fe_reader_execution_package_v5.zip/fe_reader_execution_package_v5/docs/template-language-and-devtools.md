# Workflow Template Language and Developer Tools

Workflow packs are a major differentiator. They need a developer experience, not just JSON blobs.

## Package format

```text
workflow-pack/
  workflow-pack.json
  templates/*.json
  policies/*.json
  tests/*.yaml
  fixtures/README.md
  README.md
```

## Developer commands

```bash
fe-reader workflow lint workflows/legal
fe-reader workflow test workflows/legal --fixtures fixtures/corpus
fe-reader workflow explain workflows/healthcare/deidentify.basic.json
fe-reader workflow package workflows/legal --out dist/legal.fe-workflow.zip
```

## VS Code / JetBrains extension idea

- schema-backed editing;
- autocomplete for detector IDs, page selectors and placement anchors;
- preview against a fixture PDF;
- run template tests;
- publish package manifest.

## Template safety

Templates may propose high-risk actions, but must not bypass review. Redaction, deletion, encryption, metadata scrubbing and exports always require policy gates.
