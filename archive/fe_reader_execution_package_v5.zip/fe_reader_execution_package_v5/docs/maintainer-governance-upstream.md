# Maintainer Governance and Upstream Contribution

## Project governance

- Use an RFC/ADR process for major decisions.
- Keep a public roadmap separated from implementation tracking.
- Maintain a security policy and private vulnerability reporting process.
- Require signed commits for release maintainers.
- Keep a contributor ladder: contributor, reviewer, maintainer, release manager.

## Upstream-first rule

Fe Reader should contribute fixes upstream to libraries it depends on. Forks are allowed only when necessary and must have:

- owner;
- reason;
- upstream issue/PR link;
- rebase cadence;
- security review;
- exit criteria.

## Candidate upstream contribution areas

- `lopdf`: safer high-level mutation helpers, parser hardening, test fixtures.
- `pdf-writer`: content stream generation helpers for annotations/stamps.
- `pdfium-render`: tile/render lifecycle and platform binding improvements.
- `rmcp`: tool policy/permission examples for document automation.
- `extism`: Rust host capability examples for desktop apps.
- `tantivy`: geometry-aware page result examples.
