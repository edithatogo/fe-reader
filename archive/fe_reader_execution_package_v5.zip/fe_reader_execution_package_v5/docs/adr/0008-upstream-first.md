# ADR 0008-upstream-first: Upstream-first dependency policy

Status: Accepted

Requirement IDs: see `docs/requirements-traceability.md`.

## Context

Fe Reader is implemented by parallel agents across core engine, rendering, platform, workflow, automation, distribution and security tracks. Decisions must be stable and discoverable.

## Decision

Use upstream crates where possible; fork only for blocking bugs or security fixes, with exit criteria and rebase cadence.

## Consequences

- Implementation may take slightly longer.
- Review and testing are simpler.
- Public APIs become more predictable.
- Risky operations become auditable.

## Rollback criteria

Rollback only if the alternative is demonstrably safer, faster, more portable and easier to test under the same acceptance criteria.
