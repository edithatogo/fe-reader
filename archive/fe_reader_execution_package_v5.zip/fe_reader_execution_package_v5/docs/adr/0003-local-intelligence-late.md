# ADR 0003-local-intelligence-late: Local intelligence staged late

Status: Accepted

Requirement IDs: see `docs/requirements-traceability.md`.

## Context

Fe Reader is implemented by parallel agents across core engine, rendering, platform, workflow, automation, distribution and security tracks. Decisions must be stable and discoverable.

## Decision

Local ML, embeddings and RAG are Wave 6+ experiments. Deterministic extraction/search/redaction must ship first.

## Consequences

- Implementation may take slightly longer.
- Review and testing are simpler.
- Public APIs become more predictable.
- Risky operations become auditable.

## Rollback criteria

Rollback only if the alternative is demonstrably safer, faster, more portable and easier to test under the same acceptance criteria.
