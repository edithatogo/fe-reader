# ADR 0001-core-boundaries: Core crate boundaries

Status: Accepted

Requirement IDs: see `docs/requirements-traceability.md`.

## Context

Fe Reader is implemented by parallel agents across core engine, rendering, platform, workflow, automation, distribution and security tracks. Decisions must be stable and discoverable.

## Decision

The core crate defines document semantics, patch planning, receipts and stable contracts. It must not depend on PDFium, Tauri, platform APIs, MCP, plugins, ML or GPU code.

## Consequences

- Implementation may take slightly longer.
- Review and testing are simpler.
- Public APIs become more predictable.
- Risky operations become auditable.

## Rollback criteria

Rollback only if the alternative is demonstrably safer, faster, more portable and easier to test under the same acceptance criteria.
