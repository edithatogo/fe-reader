# ADR 0006-secure-redaction-rewrite: Secure redaction requires sanitising rewrite

Status: Accepted

Requirement IDs: see `docs/requirements-traceability.md`.

## Context

Fe Reader is implemented by parallel agents across core engine, rendering, platform, workflow, automation, distribution and security tracks. Decisions must be stable and discoverable.

## Decision

Black boxes and incremental appends are not secure redaction. Secure mode must rewrite/prune/verify.

## Consequences

- Implementation may take slightly longer.
- Review and testing are simpler.
- Public APIs become more predictable.
- Risky operations become auditable.

## Rollback criteria

Rollback only if the alternative is demonstrably safer, faster, more portable and easier to test under the same acceptance criteria.
