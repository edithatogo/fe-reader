# License and Community Strategy

## Suggested licensing

Use `Apache-2.0 OR MIT` for core crates unless a deliberate copyleft decision is made later. This maximises downstream adoption, contributions and platform packaging.

## Contributor requirements

- Developer Certificate of Origin or CLA decision must be made early.
- Security-sensitive contributions need reviewer approval.
- Workflow packs may have separate licenses but must declare them.
- Test corpus licensing must be explicit and auditable.

## Community positioning

Avoid positioning as a copy of any one vendor. Position as:

- local-first;
- workflow-oriented;
- auditable;
- cross-platform;
- open ecosystem;
- performance-measured;
- privacy-preserving.
