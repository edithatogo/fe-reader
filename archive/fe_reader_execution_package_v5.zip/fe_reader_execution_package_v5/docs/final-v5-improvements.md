# Final v5 Improvements

v5 adds the last layers needed before handing Fe Reader to a coding model for sustained implementation.

## New recommendation summary

1. Add requirements traceability so every feature, test and Conductor task maps to a stable requirement ID.
2. Add ADR governance so architectural choices remain reviewable and reversible.
3. Add public API compatibility gates for Rust crates, UniFFI contracts, CLI commands, MCP tools, local automation API, and plugin ABI.
4. Add reproducible development environments: `rust-toolchain.toml`, Dev Containers, optional Nix flakes, and pinned tool manifests.
5. Add transaction journaling and crash-safe undo/redo for every mutating operation.
6. Add property, mutation, differential, visual and standards testing as distinct test classes.
7. Add local automation API contracts, but keep them loopback-only and policy-gated.
8. Add template/plugin developer tooling so workflow packs can be authored, linted, tested and packaged safely.
9. Add document health/lint/fix features as a product differentiator.
10. Add enterprise managed policy templates for Windows, macOS, Linux, Android and iOS.

## Product stance

Fe Reader is not framed as a clone of a single incumbent. It is a local-first PDF workflow platform that provides:

- industry baseline reading/editing features;
- verified high-risk operations;
- metadata transparency;
- deterministic search and redaction first;
- optional local intelligence later;
- safe automation surfaces;
- extensible workflow packs;
- first-class platform integration;
- strong performance engineering.

## Non-negotiable implementation rule

All mutating operations must be represented as a typed intent, a reviewed patch plan, an append-only transaction journal entry, a verification result and a receipt. This rule applies to UI, CLI, MCP, COM, AppleScript, D-Bus, intents, plugins, browser extension calls and local HTTP API calls.
