# Data Model Migrations

Fe Reader stores local state: recent documents, workspace records, search indexes, receipts, transaction journals, workflow packs, plugin trust records and user preferences.

## Migration requirements

- Every persisted schema has a version.
- Migrations are idempotent.
- Downgrade behaviour is documented.
- Failed migration does not corrupt documents.
- Workspace migrations are backed up before applying.

## Schema families

- workspace catalog;
- transaction journal;
- receipts;
- search index metadata;
- workflow pack state;
- plugin trust database;
- enterprise policy cache;
- diagnostics preferences.

## Command

```bash
fe-reader migrate --workspace .fe-reader --dry-run
fe-reader migrate --workspace .fe-reader --apply
```
