# Disaster Recovery and Crash Safety

## Goals

- Never lose or corrupt the source PDF during a write.
- Recover from process crash during export, redaction or save.
- Explain recovery choices to the user.
- Preserve forensic receipts where possible.

## Write algorithm

1. Create operation intent.
2. Hash input file and record size/mtime.
3. Build patch plan.
4. Write journal entry.
5. Write output to temp file on same volume when possible.
6. Flush and fsync output.
7. Verify output.
8. Atomically rename or present as new version.
9. Commit journal.
10. Emit receipt.

## Recovery states

- temp output exists but unverified;
- verified output exists but not renamed;
- source changed during operation;
- journal exists but no temp file;
- receipt missing but output verified.

## UX

The recovery UI should show: what happened, what was being done, what file was affected, and safe actions.
