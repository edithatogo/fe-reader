# Cancellation, Resource Limits and Backpressure

PDFs can be huge or malicious. Every long-running API must support cancellation and resource budgets.

## Budget dimensions

- wall-clock time;
- CPU time;
- memory;
- rendered pixels;
- maximum pages;
- maximum image dimensions;
- maximum embedded file size;
- maximum recursive object depth;
- maximum incremental revisions;
- maximum plugin execution time.

## Required behaviour

- Budget exceeded returns a typed error, not a panic.
- UI receives progress and cancellation hooks.
- CLI exits with stable error codes.
- MCP/local API returns structured cancellation/resource errors.
- Transaction journal rolls back or marks recovery state.

## Default policy

Read-only operations may be cancelled freely. Mutating operations must either complete verified output or leave recoverable journal state.
