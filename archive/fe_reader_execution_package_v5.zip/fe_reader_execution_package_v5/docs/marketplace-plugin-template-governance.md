# Plugin and Workflow Marketplace Governance

A marketplace is a late-stage feature, but governance must be designed early.

## Package categories

- workflow packs;
- stamp/template packs;
- metadata templates;
- redaction recipes;
- converter providers;
- plugin modules;
- integration adapters.

## Review criteria

- license declared;
- publisher identity;
- source repository;
- hash and signature;
- capabilities declared;
- no hidden network/filesystem access;
- tests included;
- compatibility version declared.

## Trust levels

| Level | Meaning |
|---|---|
| local-dev | user-installed local package |
| community | unsigned community package |
| verified-publisher | publisher identity verified |
| official | maintained by Fe Reader project |
| enterprise-approved | approved by enterprise policy |

## Safety

Plugins can propose operations. Only policy-gated core code applies operations.
