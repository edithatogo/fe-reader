# Local Automation API

The local automation API is useful for integrations, browser extensions, editors and scripts. It must not become a remote cloud API by accident.

## Defaults

- Disabled by default in early builds.
- Loopback-only.
- Random session token generated per user profile.
- Read-only by default.
- Mutation requires policy allow rule and approval token.
- All requests are logged locally unless diagnostics are disabled.

## Surfaces

- HTTP+JSON OpenAPI contract for local apps.
- JSON-RPC over stdio for scripts and editor extensions.
- MCP for AI-agent-compatible tool access.

## Mutating operation rule

All mutation endpoints return a `PatchPlan` first. Applying a plan requires a second explicit call with the plan hash and approval token.
