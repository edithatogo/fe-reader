# Release Acceptance Playbooks

## Alpha release

- CLI can inspect/render/extract text from curated fixtures.
- Basic native app opens documents on Windows, macOS and Linux.
- Security policy blocks destructive automation by default.
- SBOM generated.
- Core tests pass under `cargo nextest`.

## Beta release

- Core reader and annotation workflows pass visual regression.
- Metadata editor and scrubber pass corpus tests.
- Secure redaction workflow passes verification tests.
- Installers work for at least Windows/macOS/Linux primary channels.
- Crash recovery works on transaction journal fixtures.

## 1.0 release

- Public API baseline captured.
- Conformance corpus and performance budgets are stable.
- Signed updates are configured.
- Packaging metadata is ready for target registries.
- Enterprise policy templates are tested.
- Accessibility baseline is tested.
- Security threat model is updated.

## LTS release

- SDK ABI stability guarantees are documented.
- Critical security fix process is rehearsed.
- Backport policy exists.
- Installer and update channels are separated by stable/beta/nightly/LTS.
