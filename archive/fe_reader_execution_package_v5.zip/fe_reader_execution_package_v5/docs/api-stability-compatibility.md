# API Stability and Compatibility

Fe Reader exposes multiple public surfaces. Each needs explicit versioning and compatibility tests.

## Surfaces

| Surface | Versioned artifact | Compatibility gate |
|---|---|---|
| Rust crates | public API | `cargo public-api`, `cargo-semver-checks` |
| UniFFI | generated Swift/Kotlin/Python/C# fallback API | generated-bindings diff |
| CLI | command/flag/schema outputs | CLI contract tests |
| MCP | tool manifests and schemas | MCP manifest diff |
| Local HTTP API | OpenAPI schema | OpenAPI diff and policy tests |
| Plugin ABI | capability manifest and WASM host ABI | plugin fixture tests |
| Workflow packs | JSON schemas and semantic version | workflow pack lint/test |
| Installer/update channels | manifests and update metadata | release readiness tests |

## SemVer policy

- `0.x`: rapid iteration, but schemas and automation contracts still require migration notes.
- `1.x`: backwards-compatible minor releases; breaking changes require major version.
- `LTS`: stable CLI, SDK, plugin ABI and enterprise policy schema for declared support window.

## Gates

```bash
cargo public-api --workspace
cargo semver-checks
cargo nextest run --workspace
fe-reader contract verify --all
fe-reader schema diff --baseline contracts/baseline
```

## Breaking-change process

1. Add ADR.
2. Add migration guide.
3. Add compatibility test demonstrating old behaviour.
4. Add deprecation notice if possible.
5. Obtain security/platform/API owner review.
