# Late Adoption Gates for Local ML, RAG and Language Models

Local intelligence is valuable but should not be early-path work.

## Deterministic prerequisites

Do not begin ML/RAG implementation until these exist:

- reliable text spans with geometry;
- deterministic search index;
- redaction plan/review/apply/verify pipeline;
- metadata scrubber;
- transaction journal;
- local automation policy;
- performance budgets;
- corpus fixtures.

## Allowed Wave 6 experiments

- local NER entity detector as an optional provider;
- local embeddings for semantic search;
- grounded document Q&A with mandatory page/bounding-box citations;
- layout classification for template suggestion;
- OCR confidence correction;
- workflow recommendations.

## Disallowed until later

- unsupervised automatic destructive redaction;
- cloud-hosted inference by default;
- model-generated edits without patch plan and human review;
- hidden telemetry/model feedback loops.

## Evaluation gates

- accuracy against labelled fixtures;
- hallucination/citation tests;
- privacy review;
- performance budget;
- opt-in UX;
- model license review;
- offline behaviour.
