# Document Workspaces and Bundles

A powerful feature beyond conventional PDF tools is the document workspace: a local project around one or more PDFs.

## Workspace contents

```text
.fe-reader/
  workspace.json
  documents/
  receipts/
  journals/
  search/
  annotations/
  workflow-runs/
  exports/
```

## Use cases

- research paper packs;
- disclosure bundles;
- clinical de-identification packs;
- engineering drawing sets;
- education marking packs;
- finance/audit packs;
- publishing/preflight projects.

## Bundle export

```bash
fe-reader bundle create --workspace .fe-reader --out case-pack.fe-bundle
fe-reader bundle verify case-pack.fe-bundle
```

Bundles should support receipts, provenance and deterministic manifests.
