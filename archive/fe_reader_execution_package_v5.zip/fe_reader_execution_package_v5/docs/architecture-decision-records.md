# Architecture Decision Records

ADRs keep the project from drifting as multiple sub-agents implement in parallel.

## When an ADR is required

Create or update an ADR when changing:

- crate boundaries;
- PDF write semantics;
- rendering backend architecture;
- public API or UniFFI contract;
- MCP/automation/plugin permission model;
- transaction journal format;
- metadata/workflow schema;
- installer/update strategy;
- security or privacy policy;
- dependency fork policy.

## ADR format

```text
adr/NNNN-short-title.md
```

Each ADR must contain:

- Status: Proposed, Accepted, Superseded, Rejected
- Date
- Requirement IDs
- Context
- Decision
- Alternatives considered
- Consequences
- Rollback criteria
- Review cadence

## Initial ADR backlog

| ADR | Topic | Status |
|---|---|---|
| `0001` | Core crate must not depend on renderer, UI, platform or automation | Accepted |
| `0002` | Mutating operations use intent-plan-transaction-verify-receipt | Accepted |
| `0003` | Local intelligence is Wave 6+ only | Accepted |
| `0004` | WASM plugin host starts with capability-limited proposal plugins | Proposed |
| `0005` | PDFium first renderer; GPU renderer only behind adapter | Proposed |
| `0006` | Secure redaction requires full sanitising rewrite | Accepted |
| `0007` | Automation surfaces are read-only by default | Accepted |
| `0008` | Upstream-first dependency strategy | Accepted |
