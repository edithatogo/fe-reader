# Testing: Property, Mutation and Differential Strategy

## Test types

| Type | Purpose | Example |
|---|---|---|
| Unit | Validate small pure functions | coordinate transforms |
| Property | Explore invariants across generated inputs | page reordering preserves multiset of page IDs |
| Metamorphic | Validate transformations under related inputs | rotate 90 four times returns original geometry |
| Differential | Compare against independent engines | render/extract against PDFium/PDF.js/Poppler-style adapter |
| Mutation | Ensure tests catch intentional bugs | cargo-mutants on core planning code |
| Fuzz | Exercise hostile byte inputs | page tree/xref/template/redaction parsing |
| Visual | Pixel/image diff against golden renders | annotation overlay and tile render |
| Standards | Validate formal profiles | PDF/A/PDF/UA/PDF/X where applicable |
| Scenario | End-to-end workflow | plan/apply/verify redaction |

## Property test backlog

- Coordinates map UI-to-PDF-to-UI within tolerance for crop/rotate/scale.
- Page labels remain valid after insert/delete/reorder.
- Patch plans are deterministic for identical inputs.
- Metadata scrub mode removes private fields and preserves allowed fields.
- Redaction candidate spans do not overlap outside selected page regions.
- Transaction replay either succeeds exactly or fails before output mutation.

## Mutation testing policy

Run mutation tests nightly on:

- patch planner;
- redaction planner;
- transaction journal;
- security policy;
- metadata scrubber;
- coordinate transforms.

Do not run mutation testing on every PR until baselines are stable.

## Differential testing adapters

Initial target adapters:

- production renderer: PDFium adapter;
- browser renderer: PDF.js via web harness;
- optional Linux adapter: Poppler/`pdftotext`/`pdftoppm` for external comparison;
- extraction comparison: `qpdf`, `mutool`, or `pdftotext` where available.

Differential tests are advisory until the corpus is curated. They become release gates only for stable fixtures.
