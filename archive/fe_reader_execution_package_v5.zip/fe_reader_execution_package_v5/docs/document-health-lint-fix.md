# Document Health, Lint and Fix

A strong differentiator is a document health engine that explains what is wrong with a PDF and offers safe fixes.

## Health dimensions

| Dimension | Examples |
|---|---|
| Syntax | broken xref, malformed objects, unbalanced streams |
| Security | JavaScript actions, Launch actions, embedded files, suspicious URIs |
| Privacy | metadata leaks, hidden text, embedded thumbnails, previous revisions |
| Accessibility | missing tags, reading order issues, missing alt text |
| Print | crop/bleed/trim problems, output intents, colour profile issues |
| Workflow | unsigned receipt, unverified redaction, template mismatch |
| Performance | huge images, duplicate fonts, excessive incremental updates |

## Commands

```bash
fe-reader health input.pdf --json
fe-reader lint input.pdf --profile privacy
fe-reader fix input.pdf --profile safe-share --out cleaned.pdf
```

## Fix policy

Fixes produce a patch plan first. They must be reviewable before applying.
