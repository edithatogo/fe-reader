# PDF Diff and Object Inspector

A distinctive expert feature is a transparent object inspector and diff tool.

## Diff modes

- visual diff;
- text diff;
- metadata diff;
- annotation diff;
- form field diff;
- object graph diff;
- security/action diff;
- accessibility/tag tree diff.

## Object inspector

Expose a safe read-only view of:

- xref tables/streams;
- object streams;
- page tree;
- resources;
- fonts;
- images;
- annotations;
- actions;
- embedded files;
- structure tree;
- incremental revisions.

## UX

Expert mode only. The inspector should explain objects in plain language and link them to pages/visual regions where possible.
