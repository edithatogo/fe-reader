# Transaction Journal, Undo/Redo and Crash Safety

Fe Reader should feel safe even when editing complex PDFs. The core mechanism is a transaction journal.

## Principles

- Never mutate the original file directly.
- Every operation has an intent, patch plan, journal entry, verification result and receipt.
- Redaction uses full sanitising rewrite; affidavit/stamp-style workflows may use incremental append if allowed.
- Journal files are local, encrypted where appropriate, and never synced without user action.
- Undo is semantic where possible and file-version-based where not possible.

## Flow

```mermaid
sequenceDiagram
  participant UI as UI/CLI/MCP/Plugin
  participant Core as fe_reader_core
  participant Journal as Transaction Journal
  participant Writer as PDF Writer
  participant Verify as Verifier
  UI->>Core: OperationIntent
  Core->>Core: Build PatchPlan
  Core->>Journal: Begin transaction
  Journal->>Writer: write temp output
  Writer->>Verify: verify output
  Verify-->>Journal: VerificationResult
  Journal->>Journal: commit or rollback
  Journal-->>UI: Receipt
```

## Journal states

- `planned`
- `prepared`
- `writing`
- `verifying`
- `committed`
- `rolled_back`
- `failed_needs_recovery`

## Recovery command

```bash
fe-reader recover --workspace .fe-reader --explain
fe-reader recover --workspace .fe-reader --rollback TX_ID
fe-reader recover --workspace .fe-reader --commit-if-verified TX_ID
```
