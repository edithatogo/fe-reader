# Requirements Traceability Matrix

This document is the canonical bridge between product requirements, architecture, Conductor tracks, tests and release gates.

## Identifier format

| Prefix | Meaning |
|---|---|
| `FR-READ-*` | Reading, rendering, navigation and search |
| `FR-EDIT-*` | Page, object, annotation and form editing |
| `FR-META-*` | Metadata, XMP, provenance and document properties |
| `FR-WF-*` | Workflow packs and verified operations |
| `FR-RED-*` | Redaction, sanitisation and verification |
| `FR-PLAT-*` | Platform integration |
| `FR-AUTO-*` | CLI, MCP, COM, AppleScript, D-Bus, intents and local API |
| `FR-WEB-*` | Web/PWA/browser extension |
| `FR-PERF-*` | Performance budgets and profiling |
| `FR-SEC-*` | Security, sandboxing and policy |
| `FR-TEST-*` | Corpus, fuzzing, property, mutation and differential tests |
| `FR-DIST-*` | Installers, stores, registries and updates |
| `FR-SDK-*` | SDK, plugin and template developer ecosystem |

## Matrix

| Requirement | Priority | Acceptance criteria | Conductor track | Primary tests |
|---|---:|---|---|---|
| `FR-READ-001` Open local PDF via CLI and native shell | Must | Can inspect and render first page of fixture PDFs | A, D, E | CLI smoke, corpus |
| `FR-READ-002` Tile rendering contract | Must | Tile request supports scale, rotation, crop, cancellation and budget | B, N | perf, visual |
| `FR-READ-003` Text layer with bounding boxes | Must | Extracted spans map to page coordinates and search hits | A, Q | property, corpus |
| `FR-EDIT-001` Page operations | Must | insert/delete/reorder/rotate preserve unrelated objects | A, G | property, differential |
| `FR-EDIT-002` Annotation authoring | Should | highlights, notes, drawings and stamps round-trip | D, G | visual, corpus |
| `FR-META-001` Document info and XMP editor | Must | view/edit/diff/scrub metadata with receipt | G | schema, corpus |
| `FR-META-002` Standards metadata awareness | Should | detect PDF/A, PDF/UA, PDF/X metadata and warn on breakage | G | veraPDF adapter |
| `FR-WF-001` Workflow pack engine | Must | declarative workflow pack validates and produces operation plans | F, Y | schema, CLI |
| `FR-WF-002` Legal affidavit pack | Should | initials/signature placement with template receipt | F | golden, visual |
| `FR-WF-003` Healthcare de-identification pack | Should | deterministic candidate detection and review queue | F, Q | redaction fixtures |
| `FR-RED-001` Secure redaction mode | Must | full sanitising rewrite, no incremental residual content | A, F, O | extraction absence, object scan |
| `FR-PLAT-001` Windows integration | Should | recent docs, file association, notifications, DPAPI, COM plan | E, X | platform smoke |
| `FR-PLAT-002` macOS integration | Should | Open Recent, security scoped bookmarks, Keychain, AppleScript/App Intents | E, X | platform smoke |
| `FR-PLAT-003` Linux integration | Should | XDG portals, MIME, recent files, D-Bus policy | E, X | platform smoke |
| `FR-PLAT-004` Android integration | Should | SAF, share/open intents, notification permission, print, AppSearch later | E, X | emulator smoke |
| `FR-PLAT-005` iOS/iPadOS integration | Should | document browser, Files app, share sheet, Pencil capture plan, App Intents | E, X | simulator smoke |
| `FR-AUTO-001` CLI automation | Must | CLI supports inspect, render, plan, apply, verify | A, X | CLI contract |
| `FR-AUTO-002` MCP server | Should | read-only tools enabled first; mutation requires approval token | D, O, X | policy tests |
| `FR-AUTO-003` Local automation API | Could | loopback-only OpenAPI with policy gate | X | API conformance |
| `FR-WEB-001` Web/PWA viewer | Could | browser viewer can open local files without server upload where supported | H | web smoke |
| `FR-PERF-001` Performance budgets | Must | `xtask perf` compares scenarios to budgets | N | perf CI |
| `FR-SEC-001` Threat model compliance | Must | no destructive operation bypasses policy | O | compliance script |
| `FR-TEST-001` Fuzz parser inputs | Must | fuzz targets exist for parser/page tree/redaction/template | J, U | cargo-fuzz |
| `FR-TEST-002` Differential renderer/extractor tests | Should | compare across PDFium/PDF.js/Poppler-style adapters where available | P, U | differential |
| `FR-DIST-001` Signed update releases | Should | release manifests and artifact attestations generated | R, V | release readiness |
| `FR-SDK-001` Stable SDK contracts | Should | semver and public API reports are generated | S, T | semver checks |

## Maintenance rule

No Conductor task is complete unless its requirement IDs are listed in the plan, implementation notes and test evidence.
