# v5 Coding Agent Start Here

Read in this order:

1. `IMPLEMENTATION_PROMPT.md`
2. `AGENTS.md`
3. `docs/final-v5-improvements.md`
4. `docs/requirements-traceability.md`
5. `docs/architecture-decision-records.md`
6. `conductor/waves.yaml`
7. `conductor/tracks.md`
8. `contracts/README.md`
9. `docs/testing-property-mutation-differential.md`
10. `docs/workspace-undo-transaction-journal.md`

Start implementation with Wave 0 only. Do not jump to UI polish, ML/RAG, GPU rendering, marketplace, or advanced conversions before the core contracts and CLI harness are working.
