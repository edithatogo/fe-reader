# Application Accessibility and UX Quality

PDF accessibility is not enough; the application itself must be accessible.

## App accessibility requirements

- Keyboard-only navigation.
- Screen reader labels for toolbars, annotations, page thumbnails and panels.
- High-contrast and dark mode.
- Reduced motion option.
- Configurable zoom and hit targets.
- Touch/stylus/mouse parity where practical.
- Accessible error messages and receipts.

## Reader UX requirements

- Instant resume to last document/page/zoom.
- Progressively open huge documents.
- Background thumbnail generation.
- Search result list with page and snippet.
- Undo/redo with clear receipt trail.
- Non-destructive preview for risky operations.

## Platform-specific polish

- Windows: jump lists and keyboard shortcuts consistent with Windows conventions.
- macOS/iPadOS: native document browser/Open Recent/Shortcuts where possible.
- Linux: portal-first file access and desktop-neutral shortcuts.
- Android: Material-like touch density and stylus handling.
- iOS: Files app, share sheet and Pencil-friendly flows.
