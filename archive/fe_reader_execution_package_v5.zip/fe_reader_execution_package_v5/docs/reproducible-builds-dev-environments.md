# Reproducible Builds and Developer Environments

The goal is for a new contributor or coding model to enter a predictable development environment without guessing tool versions.

## Layers

| Layer | Purpose |
|---|---|
| `rust-toolchain.toml` | pin Rust channel/components/targets |
| `.devcontainer/devcontainer.json` | reproducible containerised development |
| `flake.nix` | optional Nix development shell for reproducible system dependencies |
| `xtask` | project-owned commands for build/test/perf/release |
| `cargo-nextest` | fast deterministic Rust test runner |
| `cargo-deny`, `cargo-vet`, `cargo-audit` | supply-chain checks |
| `cargo-semver-checks`, `cargo-public-api` | SDK compatibility checks |
| `cargo-mutants` | mutation testing for high-value crates |
| `cargo-dist` | release asset packaging support |
| `release-plz` | Rust crate release PRs and changelog automation |

## Dev shell commands

```bash
rustup show
cargo check --workspace --all-targets --all-features
cargo nextest run --workspace --all-features
cargo xtask quality
cargo xtask perf smoke
```

## Nix policy

Nix is optional. It is useful for contributors who want reproducible system-level dependencies such as Java/veraPDF, Node, pnpm, Docker tooling, OpenSSL and packaging tools. Nix must not become the only supported path.

## Container policy

The dev container should include Rust, Node/pnpm, Java, Python, shellcheck, jq, cargo-nextest, cargo-deny, cargo-audit, cargo-vet, cargo-mutants and common platform-independent tools. Platform-specific signing/notarisation still occurs on native runners.
