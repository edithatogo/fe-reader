# Fe Reader Review Skill

Run this skill at the end of every Conductor phase.

## Commands

```bash
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace --all-features
python3 scripts/validate_schemas.py
python3 scripts/architecture_compliance_check.py --workspace-root .
python3 scripts/corpus_manifest_validate.py
scripts/security_policy_check.sh || true
scripts/sbom_audit.sh || true
scripts/perf_smoke.sh || true
python3 scripts/visual_regression_compare.py --smoke || true
scripts/release_readiness_check.sh || true
python3 scripts/accessibility_audit_smoke.py || true
scripts/source_linked_smoke.sh || true
scripts/optimization_oracle_smoke.sh || true
scripts/cache_workspace_smoke.sh || true
```

Then run advisory checks if available:

```bash
cargo deny check
cargo audit
cargo vet
cargo cyclonedx --format json --output-file target/sbom.cdx.json
```

## Architecture checks

Fail if:

- `fe_reader_core` depends on Tauri, PDFium, MCP, Extism, Wasmtime, Candle, Burn, platform crates, webview crates, OS automation crates, database/index crates, or UI frameworks.
- Secure redaction uses incremental append.
- Automation APIs mutate without approval tokens.
- Plugin host can directly write documents.
- Web integration can mutate files without explicit user grant.
- Platform adapters leak OS-specific types into core contracts.
- Renderer or search/indexing code mutates source documents.
- P0/P1 performance budgets regress after baselines are accepted.
- GPU, PGO, allocator, git dependencies or local-intelligence experiments become default without benchmark evidence.
- JavaScript actions, RichMedia, external file launch, embedded executables, network fetches, or plugin code execute without sandbox policy and user consent.
- Signed-update manifests are unsigned or are not bound to artifact digests.

## Auto-fix

Allowed for formatting, schema formatting and simple machine-applicable lints only. Do not auto-fix security, redaction, architecture, platform permission, corpus, release-signing, policy, or accepted performance-regression failures.


## v5 additional checks

When reviewing a phase, also check:

- Whether any new public surface changed without an API compatibility note.
- Whether any repair/recovery code can overwrite an original PDF without explicit approval.
- Whether any feature flag lacks owner, maturity and policy metadata.
- Whether new PDF support claims have a fixture, corpus note or differential oracle result.
- Whether release/distribution changes update the release evidence plan.
- Whether colour/font/prepress changes preserve unknown structures rather than silently flattening them.


## v6 additional checks

Also check:

- Mutating code uses the Document IR or explains why a direct low-level operation is safe.
- Long-running operations are represented as jobs with progress, cancellation and resource limits.
- New app UI has keyboard and accessibility acceptance notes.
- Active PDF content remains disabled or quarantined by default.
- PDF revision/time-machine tools are read-only unless a reviewed export/restore flow exists.
- Source-pipeline features record input hashes, converter versions and output hashes.
- New feature flags include owner, maturity, default state, risk and policy metadata.
- Public feature claims link to test/corpus/benchmark/release evidence.
- Agent-generated implementation does not drift from contracts, schemas and Conductor tracks.


## v6 additional checks

When reviewing a phase, also check:

- Whether new UI paths have keyboard and accessibility notes.
- Whether source-linked providers are policy-gated and cannot run arbitrary commands silently.
- Whether optimisation work emits receipts and warns on signature/conformance changes.
- Whether cache entries are keyed by document hash and never treated as authoritative.
- Whether review packets are treated as untrusted input and cannot mutate documents on import.
- Whether diagnostics and quality signals are opt-in, local-first and content-redacted.
- Whether new expert features have user documentation, CLI/test coverage and release evidence.
