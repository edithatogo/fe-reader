## Summary

## Related requirement / ADR

## Evidence

- [ ] Tests added or updated
- [ ] Schema/contract updated if needed
- [ ] Architecture boundaries preserved
- [ ] Performance/security/accessibility impact considered

## Risk

