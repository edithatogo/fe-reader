---
name: Bug report
about: Report a defect
---

## What happened?

## Expected behaviour

## Platform

## PDF fixture category

## Logs/diagnostics

