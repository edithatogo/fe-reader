---
name: Feature request
about: Propose a Fe Reader capability
---

## Problem

## Proposed capability

## Workflow pack / platform / integration area

## Evidence needed

