//! Fe Reader core contracts.
//!
//! Wave 0 rule: this crate owns stable document-operation contracts only. It must not depend on
//! Tauri, PDFium, GPU crates, OS APIs, MCP, UniFFI, plugin runtimes, or ML libraries.

#![forbid(unsafe_code)]
#![warn(missing_docs)]

use serde::{Deserialize, Serialize};
use uuid::Uuid;

/// Crate name exposed for smoke tests and workspace health checks.
pub const CRATE_NAME: &str = env!("CARGO_PKG_NAME");

/// Crate semantic version exposed for compatibility smoke tests.
pub const CRATE_VERSION: &str = env!("CARGO_PKG_VERSION");

/// Stable document identifier used by UI, CLI, MCP, plugins, and platform adapters.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct DocumentId(pub String);

impl DocumentId {
    /// Creates a fresh local document id.
    pub fn new() -> Self {
        Self(Uuid::new_v4().to_string())
    }
}

impl Default for DocumentId {
    fn default() -> Self {
        Self::new()
    }
}

/// Surface that requested an operation.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum OperationSource {
    /// Human-driven UI request.
    Ui,
    /// Command line request.
    Cli,
    /// Model Context Protocol tool request.
    Mcp,
    /// Native automation surface such as COM, AppleScript, D-Bus, Android intents, or App Intents.
    Automation,
    /// WASM plugin proposal.
    Plugin,
}

/// Mutability/risk class for an operation.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RiskLevel {
    /// Inspection only.
    ReadOnly,
    /// Reversible local state change, not a PDF mutation.
    LocalState,
    /// PDF mutation that should be reviewable before apply.
    DocumentMutation,
    /// High-risk mutation such as redaction, signing, destructive rewrite, or external export.
    HighRisk,
}

/// First-class request object for every operation surface.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct OperationIntent {
    /// Unique operation id.
    pub intent_id: String,
    /// Calling surface.
    pub source: OperationSource,
    /// Target document.
    pub document_id: DocumentId,
    /// Human-readable operation name, e.g. `inspect`, `plan_redaction`, `apply_patch`.
    pub operation: String,
    /// Risk classification decided before planning.
    pub risk_level: RiskLevel,
    /// Whether policy requires explicit review before apply.
    pub requires_review: bool,
}

impl OperationIntent {
    /// Creates a read-only operation intent.
    pub fn read_only(source: OperationSource, document_id: DocumentId, operation: impl Into<String>) -> Self {
        Self {
            intent_id: Uuid::new_v4().to_string(),
            source,
            document_id,
            operation: operation.into(),
            risk_level: RiskLevel::ReadOnly,
            requires_review: false,
        }
    }
}

/// Immutable patch-plan placeholder. Later waves replace `summary` with typed operations.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PatchPlan {
    /// Unique patch plan id.
    pub plan_id: String,
    /// Intent that produced this plan.
    pub intent_id: String,
    /// Human-readable summary.
    pub summary: String,
    /// Whether the plan may be applied without further review.
    pub approved_for_apply: bool,
}

impl PatchPlan {
    /// Creates a non-approved plan draft.
    pub fn draft(intent: &OperationIntent, summary: impl Into<String>) -> Self {
        Self {
            plan_id: Uuid::new_v4().to_string(),
            intent_id: intent.intent_id.clone(),
            summary: summary.into(),
            approved_for_apply: false,
        }
    }
}

/// Returns a stable identity string for diagnostics.
pub fn crate_identity() -> String {
    format!("{}@{}", CRATE_NAME, CRATE_VERSION)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn read_only_intent_does_not_require_review() {
        let intent = OperationIntent::read_only(OperationSource::Cli, DocumentId::new(), "inspect");
        assert_eq!(intent.risk_level, RiskLevel::ReadOnly);
        assert!(!intent.requires_review);
    }

    #[test]
    fn patch_plan_defaults_to_not_approved() {
        let intent = OperationIntent::read_only(OperationSource::Cli, DocumentId::new(), "inspect");
        let plan = PatchPlan::draft(&intent, "inspect only");
        assert!(!plan.approved_for_apply);
        assert_eq!(plan.intent_id, intent.intent_id);
    }
}
