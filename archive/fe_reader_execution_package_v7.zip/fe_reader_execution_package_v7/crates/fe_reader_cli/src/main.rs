//! Fe Reader CLI Wave 0 harness.

use anyhow::Result;
use clap::{Parser, Subcommand};

/// Local-first PDF workflow platform CLI.
#[derive(Debug, Parser)]
#[command(name = "fe-reader", version, about = "Fe Reader Wave 0 CLI harness")]
struct Cli {
    #[command(subcommand)]
    command: Command,
}

#[derive(Debug, Subcommand)]
enum Command {
    /// Print build and contract information.
    Doctor,
    /// Inspect a PDF path without mutating it. Wave 0 emits a planning stub.
    Inspect {
        /// Path to a PDF file.
        path: String,
        /// Emit JSON output.
        #[arg(long)]
        json: bool,
    },
    /// Validate local JSON schemas and contract scaffolding.
    ValidateSchemas,
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    match cli.command {
        Command::Doctor => {
            println!("fe-reader cli: {}", env!("CARGO_PKG_VERSION"));
            println!("core: {}", fe_reader_core::crate_identity());
        }
        Command::Inspect { path, json } => {
            let intent = fe_reader_core::OperationIntent::read_only(
                fe_reader_core::OperationSource::Cli,
                fe_reader_core::DocumentId::new(),
                "inspect",
            );
            let plan = fe_reader_core::PatchPlan::draft(&intent, format!("inspect {path}"));
            if json {
                println!("{}", serde_json::to_string_pretty(&plan)?);
            } else {
                println!("planned read-only inspection for {path}");
                println!("plan_id={}", plan.plan_id);
            }
        }
        Command::ValidateSchemas => {
            println!("schema validation is delegated to scripts/validate_schemas.py in Wave 0");
        }
    }
    Ok(())
}
