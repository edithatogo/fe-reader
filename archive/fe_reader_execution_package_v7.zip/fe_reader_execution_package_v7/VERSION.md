# Fe Reader Specification Package Version

Package version: v7
Generated: 2026-05-20
Status: implementation-first handoff package

v7 converts the package from a planning bundle into a Wave 0 executable scaffold. It keeps the v6 architecture but adds real Cargo workspace files, crate stubs, first-PR sequencing, error/migration contracts, file-format versioning, risk/IP governance, and explicit "stop expanding, start implementing" rules.
